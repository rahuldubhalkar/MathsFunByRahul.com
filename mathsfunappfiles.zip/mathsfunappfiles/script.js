let num1, num2, correctAnswer, operation;
let score = 0;
let questionCount = 0;
let timer;

function startTimer() {
  let time = 10;
  timer = setInterval(function() {
    document.getElementById('timer').innerText = `Time: ${time}`;
    time--;
    if (time < 0) {
      clearInterval(timer);
      showResult();
    }
  }, 1000);
}

function startGame() {
  if (questionCount === 20) {
    showFinalScore();
    return;
  }
  clearInterval(timer);
  startTimer();
  const operations = ['add', 'sub', 'mul', 'div'];
  operation = operations[Math.floor(Math.random() * operations.length)];
  document.getElementById('userAnswer').value = '';
  document.getElementById('questionText').innerText = generateQuestion();
  document.getElementById('result').style.display = 'none';
  document.querySelector('.question button:nth-of-type(2)').style.display = 'none';
  document.querySelector('.question button:nth-of-type(1)').style.display = 'block';
  document.getElementById('userAnswer').disabled = false;
  document.getElementById('userAnswer').focus();
  questionCount++;
}

function generateQuestion() {
  num1 = Math.floor(Math.random() * 10) + 1;
  num2 = Math.floor(Math.random() * 10) + 1;
  let question = '';

  switch (operation) {
    case 'add':
      correctAnswer = num1 + num2;
      question = `${num1} + ${num2} = `;
      break;
    case 'sub':
      correctAnswer = num1 - num2;
      question = `${num1} - ${num2} = `;
      break;
    case 'mul':
      correctAnswer = num1 * num2;
      question = `${num1} * ${num2} = `;
      break;
    case 'div':
      correctAnswer = Math.floor((num1 * num2) / num2);
      question = `${num1 * num2} / ${num2} = `;
      break;
    default:
      break;
  }

  return question;
}

function showResult() {
  clearInterval(timer);
  const userAnswer = parseInt(document.getElementById('userAnswer').value);
  const resultElement = document.getElementById('result');
  const nextButton = document.querySelector('.question button:nth-of-type(2)');

  if (userAnswer === correctAnswer) {
    resultElement.innerText = 'Correct!';
    score++;
    document.getElementById('score').innerText = score;
  } else {
    resultElement.innerText = 'Incorrect. Try again!';
  }

  resultElement.style.display = 'block';
  nextButton.style.display = 'block';
  document.getElementById('userAnswer').disabled = true;
}

function nextQuestion() {
  document.getElementById('result').style.display = 'none';
  document.querySelector('.question button:nth-of-type(2)').style.display = 'none';
  startGame();
}

function showFinalScore() {
  document.querySelector('.question').innerHTML = `<p>Final Score: ${score}</p>`;
}

// Start the game initially
startGame();
